export { DebugConsoleTab } from '@/components/panels/bottom/tabs/debug-console-tab';
export { OutputTab } from '@/components/panels/bottom/tabs/output-tab';
export { ProblemsTab } from '@/components/panels/bottom/tabs/problems-tab';
export { TerminalTab } from '@/components/panels/bottom/tabs/terminal-tab';

